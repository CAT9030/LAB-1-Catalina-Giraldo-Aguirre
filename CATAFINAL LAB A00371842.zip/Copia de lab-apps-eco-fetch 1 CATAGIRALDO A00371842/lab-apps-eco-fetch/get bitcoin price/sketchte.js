let canvas;
let URL = 'https://api.coindesk.com/v1/bpi/currentprice.json';
let bit =null;
let coin = null;
/*const reload = document.getElementById('reload');

    reload.addEventListener('click', _ => { // el _ es para indicar la ausencia de parametros
        location.reload();
    });*/




function setup() {
    frameRate(60);
    canvas = createCanvas(windowWidth, windowHeight);
    canvas.style('z-index', '-1');
    canvas.style('position', 'fixed');
    canvas.style('top', '0');
    canvas.style('right', '0');
    
   fetch (URL)
   .then(response => response.json())
        .then(data => {
            bit = data
            console.log(data)
            console.log(bit.time.updated);
            console.log(bit.chartName)
            console.log(bit.bpi.USD.code)
            console.log(bit.bpi.USD.rate)

            coin = `Fecha: ${bit.time.updated}
            Moneda: ${bit.bpi.USD.code}
            Precio: ${bit.bpi.USD.rate}`

            console.log(coin)
        });
}

 function draw() {
  /*background(0);
    newCursor();

    fill(255);
    textSize(20);
    textWrap(WORD);

    if (coin != null) {

      text(coin, 100, 700, 300)
  }*/
  background(0);
    newCursor();

    if(coin != null) {
    
   textSize(30);
    textWrap(WORD);
    text("Click on the screen to refresh",30,30,300);
    text(coin, 30, 200, 300);
    }


 
}



function mouseClicked(){
    fetch (URL)
   .then(response => response.json())
        .then(data => {
            bit = data
            console.log(data)
            console.log(bit.time.updated);
            console.log(bit.chartName)
            console.log(bit.bpi.USD.code)
            console.log(bit.bpi.USD.rate)

            coin = `Fecha: ${bit.time.updated}
            Moneda: ${bit.bpi.USD.code}
            Precio: ${bit.bpi.USD.rate}`

            console.log(coin)
        });
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function newCursor() {
  noStroke();
  fill(255);
  ellipse(pmouseX, pmouseY, 10, 10);}