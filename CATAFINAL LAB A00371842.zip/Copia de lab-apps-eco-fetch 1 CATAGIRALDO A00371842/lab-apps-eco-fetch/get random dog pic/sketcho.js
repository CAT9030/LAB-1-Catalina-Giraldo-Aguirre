let canvas;
let URL = 'https://dog.ceo/api/breeds/image/random';
const reload = document.getElementById('reload');

    reload.addEventListener('click', _ => { // el _ es para indicar la ausencia de parametros
        location.reload();
    });
const dogbtn = document.getElementById("dogbtn");



function setup() {
    frameRate(60);
    canvas = createCanvas(windowWidth, windowHeight);
    canvas.style('z-index', '-1');
    canvas.style('position', 'fixed');
    canvas.style('top', '0');
    canvas.style('right', '0');

    
}
          
async function getDog(){
    const resp = await fetch(URL);
    const data =  await resp.json();
    console.log(data);
    showdata(data.message);
 }

 getDog();

 function showdata(dogimage){
  document.getElementById("dog").innerHTML = `
  <img src="${dogimage}" alt="">
  `
}


 function draw() {
  newCursor();
  background(0, 50);
  background(0);
 
}



function mouseClicked(){
    
   
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function newCursor() {
  noStroke();
  fill(255);
  ellipse(pmouseX, pmouseY, 10, 10);}