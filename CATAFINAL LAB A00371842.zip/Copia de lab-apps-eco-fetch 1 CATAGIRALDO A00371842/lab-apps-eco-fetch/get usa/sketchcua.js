let canvas;
let URL = 'https://datausa.io/api/data?drilldowns=Nation&measures=Population';
let usa = null;
/*const reload = document.getElementById('reload');

    reload.addEventListener('click', _ => { // el _ es para indicar la ausencia de parametros
        location.reload();
    });*/




function setup() {
    frameRate(60);
    canvas = createCanvas(windowWidth, windowHeight);
    canvas.style('z-index', '-1');
    canvas.style('position', 'fixed');
    canvas.style('top', '0');
    canvas.style('right', '0');

    fetch(URL)
    .then(response => response.json())
    .then(data => {
      usa= data.data [0].Nation +" " + data.data [0].Year + " " +data.data[0].Population
        console.log(usa) 
    
})

  }

  

  

 function draw() {
  /*background(0);
    newCursor();

    fill(255);
    textSize(20);
    textWrap(WORD);

    if (coin != null) {

      text(coin, 100, 700, 300)
  }*/
  background(0);
    newCursor();

    if(usa != null) {
    
   textSize(30);
    textWrap(WORD);
    text("Click on the screen to refresh",30,30,300);
    text(usa, 30, 200, 300);
    
  }

 
}



function mouseClicked(){
 
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function newCursor() {
  noStroke();
  fill(255);
  ellipse(pmouseX, pmouseY, 10, 10);}